import os
import random as rnd
from mdvrp_desenho import desenha_solucao

def le_dados_instancia(arq_instancia):
    with open(arq_instancia, 'r') as f:
        linhas_arquivo = f.readlines()

        #Quantidade de depositos
        qtd_depositos = int(linhas_arquivo[0].strip().split(';')[1])
        #Quantidade de clientes
        qtd_clientes = int(linhas_arquivo[1].strip().split(';')[1])
        #Capacidade dos veículo s
        capac_veiculos = int(linhas_arquivo[2].strip().split(';')[1])
        del(linhas_arquivo[0:5])

        #Coordenadas e Demandas
        qtd_pontos = qtd_clientes + qtd_depositos
        lista_coordenadas = list()
        lista_demandas = list()
        for i in range(qtd_pontos):
            vet_linha = linhas_arquivo[i].strip().split(';')
            x = int(vet_linha[1])
            y = int(vet_linha[2])
            demanda = int(vet_linha[3])

            lista_coordenadas.append((x, y))
            lista_demandas.append(demanda)
        del(linhas_arquivo[0:qtd_pontos + 2])

        #Le a matriz de distâncias
        mat_dist = list()
        for linha in linhas_arquivo:
            valores = linha.strip().split(';')
            del(valores[0])
            valores_int = list()
            for v in valores:
                valores_int.append(int(v))
            mat_dist.append(valores_int)

    return mat_dist, lista_demandas, capac_veiculos, qtd_clientes, qtd_depositos


def gera_solucao_aleatoria(qtd_clientes, qtd_depositos, mat_dist, lista_demandas, capac_veiculos):
    area_depositos = []
    linha = list()
    for deposito in range(0, qtd_depositos):
        for cliente in range(qtd_depositos, qtd_clientes + qtd_depositos):
            menor_distancia = 999999
            for d in range(0, qtd_depositos):
                if mat_dist[cliente][d] < menor_distancia:
                    menor_distancia = mat_dist[cliente][d]
                    deposito_proximo = d

            if deposito_proximo == deposito:
                linha.append(cliente)
            else:
                linha.append(0)
        area_depositos.append(linha)
        linha = []

    solucao = list()
    for deposito in range(0, qtd_depositos):
        rnd.shuffle(area_depositos[deposito])
        rota = [deposito]
        capac_usada = 0
        for cliente in area_depositos[deposito]:
            if cliente != 0:
                demanda_cliente = lista_demandas[cliente]
                if capac_usada + demanda_cliente <= capac_veiculos:
                    rota.append(cliente)
                    capac_usada += demanda_cliente
                else:
                    rota.append(deposito)
                    solucao.append(rota)
                    rota = [deposito, cliente]
                    capac_usada = demanda_cliente
        rota.append(deposito)
        solucao.append(rota)

    return solucao


def calcula_custo_rota(rota, mat_dist):
    custo_total = 0
    for i in range(len(rota) - 1):
        de = rota[i]
        para = rota[i + 1]
        custo_total += mat_dist[de][para]

    return custo_total


def encontra_melhor_vizinho(sol, mat_dist):
    melhor_vizinho = list()
    for rota in sol:
        melhor_rota = rota[:]
        nova_rota = rota[:]
        melhor_custo = calcula_custo_rota(melhor_rota, mat_dist)
        for i in range(0, len(rota) - 3):
            menor_distancia = 999999999
            for j in range(i + 1, len(rota) - 1):
                if mat_dist[nova_rota[i]][nova_rota[j]] < menor_distancia:
                    menor_distancia = mat_dist[nova_rota[i]][nova_rota[j]]
                    posicao = j
            melhor_rota[i+1] = nova_rota[posicao]
            melhor_rota[posicao] = nova_rota[i+1]
            nova_rota = melhor_rota[:]

        custo_nova_rota = calcula_custo_rota(nova_rota, mat_dist)
        if custo_nova_rota < melhor_custo:
            melhor_custo = custo_nova_rota
            melhor_vizinho.append(melhor_rota)
        else:
            melhor_vizinho.append(rota)

    return melhor_vizinho


def hill_climbing(qtd_clientes, qtd_depositos, mat_dist, lista_demandas, capac_veiculos, qtd_iteracoes):
    menor_custo = 999999999
    contador = 1
    sol_hill = []
    sol_local = []
    glob = [0]
    inicial = [0]
    local = [0]

    while contador <= qtd_iteracoes:
        #Gera uma solução aleatória
        sol = gera_solucao_aleatoria(qtd_clientes, qtd_depositos, mat_dist, lista_demandas, capac_veiculos)

        #Melhor Vizinho
        sol_viz = encontra_melhor_vizinho(sol, mat_dist)

        custo_rota = 0
        custo_rota_inicial = 0
        for i in range(0, len(sol_viz)):
            custo_rota += calcula_custo_rota(sol_viz[i], mat_dist)
            custo_rota_inicial += calcula_custo_rota(sol[i], mat_dist)
        if custo_rota < menor_custo:
            menor_custo = custo_rota
            sol_local = sol_viz
        contador += 1

        glob.append(menor_custo)
        inicial.append(custo_rota_inicial)
        local.append(custo_rota)

    sol_hill = sol_local

    return sol_hill, glob, inicial, local


def avalia_solucao(sol, mat_dist, lista_demandas):
    lista_cargas = list()
    lista_custo = list()

    for rota in sol:
        custo_rota = 0
        carga_rota = 0
        for i in range(len(rota) - 1):
            carga_rota += lista_demandas[rota[i]]
            custo_rota += mat_dist[rota[i]][rota[i + 1]]
        lista_custo.append(custo_rota)
        lista_cargas.append(carga_rota)
    custo_total = sum(lista_custo)

    return custo_total, lista_custo, lista_cargas


#Função que salva uma solução em um arquivo CSV
def salva_solucao(sol, arq_solucao, mat_dist, lista_demandas):
    custo_total, lista_custo, lista_cargas = avalia_solucao(sol, mat_dist, lista_demandas)

    with open(arq_solucao, 'w+') as f:
        f.write("CUSTO_TOTAL;{}\n".format(custo_total))
        f.write("QTD_ROTAS;{}\n".format(len(lista_custo)))
        f.write("ID;CUSTO;CARGA;SEQUENCIA\n")
        for idx, rota in enumerate(sol):
            f.write("{};{};{}".format(idx, lista_custo[idx], lista_cargas[idx]))
            for ponto in rota:
                f.write(";{}".format(ponto))
            f.write('\n')


#Função que salva uma solução em um arquivo CSV
def salva_relatorio(glob, inicial, local, arq_rel, qtd_iteracoes):
    with open(arq_rel, 'w+') as f:
        f.write("INTERACAO;INICIAL;LOCAL;GLOBAL\n")
        for idx in range(1, qtd_iteracoes + 1):
            f.write("{};{};{};{}".format(idx, inicial[idx], local[idx], glob[idx]))
            f.write('\n')


#Função que resolve uma instância e salva a solução em um arquivo de solução
def resolve_instancia(arq_inst, arq_sol, arq_rel, qtd_iteracoes):
    #Le os dados da instância
    mat_dist, lista_demandas, capac_veiculos, qtd_clientes, qtd_depositos = le_dados_instancia(arq_inst)

    #Hill Climbing
    sol_hill, glob, inicial, local = hill_climbing(qtd_clientes, qtd_depositos, mat_dist, lista_demandas, capac_veiculos, qtd_iteracoes)

    #Salva a solução gerada no arquivo de solução
    salva_solucao(sol_hill, arq_sol, mat_dist, lista_demandas)

    #Salva os resultados geradados no arquivo de relatorio
    salva_relatorio(glob, inicial, local, arq_rel, qtd_iteracoes)

if __name__ == '__main__':
    pasta_instancias = "Instancias/"
    pasta_solucoes = "Solucoes/"
    pasta_relatorios = "Relatorios/"
    qtd_iteracoes = 1000
    pasta_desenhos = "Desenhos/"
    for arq_inst in os.listdir(pasta_instancias):
        extensao = arq_inst.split('.')[-1]
        if extensao != 'csv':
            continue
        resolve_instancia(pasta_instancias + arq_inst, pasta_solucoes + arq_inst, pasta_relatorios + arq_inst, qtd_iteracoes)
        desenha_solucao(pasta_instancias + arq_inst, pasta_solucoes + arq_inst, pasta_desenhos + arq_inst.split('.')[0] + ".html")
