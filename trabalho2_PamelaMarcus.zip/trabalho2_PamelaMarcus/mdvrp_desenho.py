#####################################################################################
# Este programa desenha uma solução MDVRP a partir de um arquivo de solução.
# Para isso, é essencial que o arquivo de solução esteja no formato correto,
# segundo as especificações do trabalho.
#
# INSTRUÇÕES DE USO:
# 1) Este arquivo deve estar na mesma pasta que o arquivo .py do seu programa
# 2) Em seu programa, importar a função que desenha soluções
#    from mdvrp_desenho import desenha_solucao
# 3) Agora você pode usar a função desenha_solucao onde quiser
#
# PARÂMETROS
# desenha_solucao(arquivo_instancia, arquivo_solucao, arquivo_desenho)
# - arquivo_instancia: nome do arquivo com os dados da instância
# - arquivo_solucao: nome do arquivo com a solução no formato especificado
# - arquivo_desenho: nome do arquivo a ser criado com o desenho (com extensão .html)
#
# IMPORTANTE: Para abrir arquivos HTML, use seu navegador de internet
#####################################################################################

# Lê as coordenadas de todos os pontos de um arquivo de instância
def le_coordenadas_instancia(arq_instancia):
    with open(arq_instancia, 'r') as f:
        linhas = f.readlines()
        qtd_depositos = int(linhas[0].split(';')[1].strip())
        qtd_clientes = int(linhas[1].split(';')[1].strip())
        qtd_pontos = qtd_depositos + qtd_clientes
        del(linhas[:5])
        coords = list()
        for i in range(qtd_pontos):
            valores = linhas[i].strip().split(';')
            coords.append((int(valores[1]), int(valores[2])))
    return coords, qtd_depositos, qtd_clientes


# Lê as rotas de um arquivo de solução
def le_rotas_solucao(arq_solucao):
    with open(arq_solucao, 'r') as f:
        linhas = f.readlines()
        qtd_rotas = int(linhas[1].strip().split(';')[1])
        rotas = list()
        del(linhas[:3])
        for i in range(qtd_rotas):
            valores = linhas[i].strip().split(';')
            rota_atual = list()
            for ponto in valores[3:]:
                rota_atual.append(int(ponto))
            rotas.append(rota_atual)
    return rotas, qtd_rotas


# Cria o arquivo SVG com o desenho da solução
def desenha_solucao(arq_instancia, arq_solucao, arq_desenho):
    coords, qtd_depositos, qtd_clientes = le_coordenadas_instancia(arq_instancia)
    qtd_pontos = qtd_depositos + qtd_clientes
    rotas, _ = le_rotas_solucao(arq_solucao)
    with open(arq_desenho, 'w+') as f:
        f.write('<!DOCTYPE html>\n<html>\n<body>\n<svg width="1100" height="1100">\n')
        for rota in rotas:
            for i in range(len(rota) - 1):
                x1 = coords[rota[i]][0]
                y1 = coords[rota[i]][1]
                x2 = coords[rota[i + 1]][0]
                y2 = coords[rota[i + 1]][1]
                f.write('<line x1="{}" y1="{}" x2="{}" y2="{}" stroke-width="2" stroke="black"/>\n'.format(x1, y1, x2, y2))
        for ponto in range(qtd_depositos):
            x = coords[ponto][0]
            y = coords[ponto][1]
            f.write('<circle cx="{}" cy="{}" r="10" stroke="black" stroke-width="2" fill="red"/>\n'.format(x, y))
            f.write('<text x="{}" y="{}" text-anchor="middle" stroke-width="1px" dominant-baseline="middle" font-size="8">{}</text>\n'.format(x, y, ponto))
        for ponto in range(qtd_depositos, qtd_pontos):
            x = coords[ponto][0]
            y = coords[ponto][1]
            f.write('<circle cx="{}" cy="{}" r="10" stroke="black" stroke-width="2" fill="white"/>\n'.format(x, y))
            f.write('<text x="{}" y="{}" text-anchor="middle" stroke-width="1px" dominant-baseline="middle" font-size="8">{}</text>\n'.format(x, y, ponto))
        f.write("</svg>\n</body>\n</html>")


# Desenha apenas uma rota da solução, usando o ID da rota indexado em zero
def desenha_solucao_rota(arq_instancia, arq_solucao, arq_desenho, id_rota=0):
    coords, qtd_depositos, qtd_clientes = le_coordenadas_instancia(arq_instancia)
    qtd_pontos = qtd_depositos + qtd_clientes
    rotas, _ = le_rotas_solucao(arq_solucao)
    with open(arq_desenho, 'w+') as f:
        f.write('<!DOCTYPE html>\n<html>\n<body>\n<svg width="1100" height="1100">\n')
        rota = rotas[id_rota]
        for i in range(len(rota) - 1):
            x1 = coords[rota[i]][0]
            y1 = coords[rota[i]][1]
            x2 = coords[rota[i + 1]][0]
            y2 = coords[rota[i + 1]][1]
            f.write('<line x1="{}" y1="{}" x2="{}" y2="{}" stroke-width="2" stroke="black"/>\n'.format(x1, y1, x2, y2))
        for ponto in range(qtd_depositos):
            x = coords[ponto][0]
            y = coords[ponto][1]
            if ponto in rota:
                f.write('<circle cx="{}" cy="{}" r="10" stroke="black" stroke-width="2" fill="red"/>\n'.format(x, y))
                f.write('<text x="{}" y="{}" text-anchor="middle" stroke-width="1px" dominant-baseline="middle" font-size="8">{}</text>\n'.format(x, y, ponto))
            else:
                f.write('<circle cx="{}" cy="{}" r="10" stroke="rgb(180,180,180)" stroke-width="2" fill="rgb(255,204,203)" fill-opacity="0.75" stroke-opacity="0.75"/>\n'.format(x, y))
                f.write('<text x="{}" y="{}" text-anchor="middle" stroke-width="1px" stroke="rgb(180,180,180)" dominant-baseline="middle" font-size="8">{}</text>\n'.format(x, y, ponto))
        for ponto in range(qtd_depositos, qtd_pontos):
            x = coords[ponto][0]
            y = coords[ponto][1]
            if ponto in rota:
                f.write('<circle cx="{}" cy="{}" r="10" stroke="black" stroke-width="2" fill="white"/>\n'.format(x, y))
                f.write('<text x="{}" y="{}" text-anchor="middle" stroke-width="1px" dominant-baseline="middle" font-size="8">{}</text>\n'.format(x, y, ponto))
            else:
                f.write('<circle cx="{}" cy="{}" r="10" stroke-width="2" stroke="rgb(180,180,180)" fill="white"/>\n'.format(x, y))
                f.write('<text x="{}" y="{}" text-anchor="middle" stroke-width="1px" stroke="rgb(180,180,180)" dominant-baseline="middle" font-size="8">{}</text>\n'.format(x, y, ponto))
        f.write("</svg>\n</body>\n</html>")
