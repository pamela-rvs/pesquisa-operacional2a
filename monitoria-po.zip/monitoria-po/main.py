import os
import random as rnd

def le_dados_instancia(arq_instancia):
    with open(arq_instancia, 'r') as f:
        linhas_arquivo = f.readlines()

        #Quantidade de Máquinas
        qtd_maquinas = int(linhas_arquivo[0].strip().split(';')[1])
        #Quantidade de Jobs
        qtd_jobs = int(linhas_arquivo[1].strip().split(';')[1])
        #Recursos
        recursos = int(linhas_arquivo[2].strip().split(';')[1])
        del(linhas_arquivo[0:4])

        #print("Quantidade de Máquinas:", qtd_maquinas)
        #print("Quantidade de Jobs:", qtd_jobs)
        #print("Recursos:", recursos)

        #Dados das Máquinas
        velocidade = list()
        custo_tempo = list()
        for i in range(qtd_maquinas):
            velocidade.append(float(linhas_arquivo[i].strip().split(';')[1]))
            custo_tempo.append(float(linhas_arquivo[i].strip().split(';')[2]))
        del(linhas_arquivo[0:qtd_maquinas + 1])

        #print("Velocidade:", velocidade)
        #print("Custo Tempo:", custo_tempo)

        #Dados dos Jobs
        tempo_base = list()
        for i in range(qtd_jobs):
            tempo_base.append(float(linhas_arquivo[i].strip().split(';')[1]))
        #Del Opcional - del(linhas_arquivo[0:qtd_jobs])

        #print("Tempo Base:", tempo_base)

    return qtd_maquinas, qtd_jobs, recursos, velocidade, custo_tempo, tempo_base


def heuristica(qtd_maquinas, qtd_jobs, recursos, velocidade, custo_tempo, tempo_base):
    makespan = 0
    recurso_usado = 0
    solucao = list()

    tempo_maq = [0]*qtd_maquinas



    return makespan, recurso_usado, solucao


#Função que salva uma solução em um arquivo CSV
def salva_solucao(arq_solucao, makespan, recurso_usado, solucao):
    with open(arq_solucao, 'w+') as f:
        f.write("MAKESPAN;{}\n".format(makespan))
        f.write("RECURSOS_USADOS;{}\n".format(recurso_usado))
        f.write("FABRICA;JOBS\n")
        for i, job in enumerate(solucao):
            f.write("{}".format(i))
            for j in job:
                f.write(";{}".format(j))
            f.write('\n')

#Função que resolve uma instância e salva a solução em um arquivo de solução
def resolve_instancia(arq_inst, arq_sol):
    #Le os dados da instância
    qtd_maquinas, qtd_jobs, recursos, velocidade, custo_tempo, tempo_base = le_dados_instancia(arq_inst)

    #Problema de sequenciamento de produção em máquinas paralelas para minimizar o makespan
    makespan, recurso_usado, solucao = heuristica(qtd_maquinas, qtd_jobs, recursos, velocidade, custo_tempo, tempo_base)

    #Salva a solução gerada no arquivo de solução
    salva_solucao(arq_sol, makespan, recurso_usado, solucao)


if __name__ == '__main__':
    pasta_instancias = "Instancias/"
    pasta_solucoes = "Solucoes/"

    for arq_inst in os.listdir(pasta_instancias):
        extensao = arq_inst.split('.')[-1]
        if extensao != 'csv':
            continue
        #Le os dados da instância
        resolve_instancia(pasta_instancias + arq_inst, pasta_solucoes + arq_inst)
