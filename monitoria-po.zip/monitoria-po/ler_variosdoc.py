# MONITORIA - PESQUISA OPERACIONAL 2A - PÂMELA
# COMO LER VÁRIOS ARQUIVOS

import os

def le_dados(arq_instancia):

    #Estrutura padrão para percorrer as linhas do documento
    with open(arq_instancia, 'r') as f:
        #Verifica quantas linhas tem o arquivo
        linhas_arquivo = f.readlines()

        #Quantidade de Máquinas
        qtd_maquinas = int(linhas_arquivo[0].strip().split(';')[1])
        #Quantidade de Jobs
        qtd_jobs = int(linhas_arquivo[1].strip().split(';')[1])
        #Recursos
        recursos = int(linhas_arquivo[2].strip().split(';')[1])

        #Imprimi os valores lidos
        print("Quantidade de Máquinas:", qtd_maquinas)
        print("Quantidade de Jobs:", qtd_jobs)
        print("Recursos:", recursos, "\n")

        #Deleta as linhas que já foram lidas
        del(linhas_arquivo[0:4])

        #Dados das Máquinas
        velocidade = list()
        custo_tempo = list()
        for i in range(qtd_maquinas):
            #.append >> adiciona um valor no final da lista
            velocidade.append(float(linhas_arquivo[i].strip().split(';')[1]))
            custo_tempo.append(float(linhas_arquivo[i].strip().split(';')[2]))

        #Deleta as linhas que já foram lidas
        del(linhas_arquivo[0:qtd_maquinas + 1])

        #Imprimi os valores lidos
        print("Velocidade:", velocidade)
        print("Custo Tempo:", custo_tempo, "\n")

        #Dados dos Jobs
        tempo_base = list()
        for i in range(qtd_jobs):
            tempo_base.append(float(linhas_arquivo[i].strip().split(';')[1]))

        #Del Opcional - del(linhas_arquivo[0:qtd_jobs])

        #Imprimi os valores lidos
        print("Tempo Base:", tempo_base)

    return qtd_maquinas, qtd_jobs, recursos, velocidade, custo_tempo, tempo_base


if __name__ == '__main__':
    pasta_instancias = "Instancias/"

    #Percorrer todos os arquivos na pasta
    for arq_inst in os.listdir(pasta_instancias):
        extensao = arq_inst.split('.')[-1]

        #Verifica se a extensao é ".csv"
        if extensao == 'csv':
            # print("\n ============================================= \n")
            # print("INSTÂNCIA: ", arq_inst, "\n")

            #Le os dados da instância
            qtd_maquinas, qtd_jobs, recursos, velocidade, custo_tempo, tempo_base = le_dados(pasta_instancias + arq_inst)

