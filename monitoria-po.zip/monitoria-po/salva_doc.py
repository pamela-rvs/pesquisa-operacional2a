# MONITORIA - PESQUISA OPERACIONAL 2A - PÂMELA
# COMO LER E SALVAR VÁRIOS ARQUIVOS

import os

def le_dados(arq_instancia):

    #Estrutura padrão para percorrer as linhas do documento
    with open(arq_instancia, 'r') as f:
        #Verifica quantas linhas tem o arquivo
        linhas_arquivo = f.readlines()

        #Quantidade de Máquinas
        qtd_maquinas = int(linhas_arquivo[0].strip().split(';')[1])
        #Quantidade de Jobs
        qtd_jobs = int(linhas_arquivo[1].strip().split(';')[1])
        #Recursos
        recursos = int(linhas_arquivo[2].strip().split(';')[1])

        #Imprimi os valores lidos
        # print("Quantidade de Máquinas:", qtd_maquinas)
        # print("Quantidade de Jobs:", qtd_jobs)
        # print("Recursos:", recursos, "\n")

        #Deleta as linhas que já foram lidas
        del(linhas_arquivo[0:4])

        #Dados das Máquinas
        velocidade = list()
        custo_tempo = list()
        for i in range(qtd_maquinas):
            #.append >> adiciona um valor no final da lista
            velocidade.append(float(linhas_arquivo[i].strip().split(';')[1]))
            custo_tempo.append(float(linhas_arquivo[i].strip().split(';')[2]))

        #Deleta as linhas que já foram lidas
        del(linhas_arquivo[0:qtd_maquinas + 1])

        #Imprimi os valores lidos
        # print("Velocidade:", velocidade)
        # print("Custo Tempo:", custo_tempo, "\n")

        #Dados dos Jobs
        tempo_base = list()
        for i in range(qtd_jobs):
            tempo_base.append(float(linhas_arquivo[i].strip().split(';')[1]))

        #Del Opcional - del(linhas_arquivo[0:qtd_jobs])

        #Imprimi os valores lidos
        # print("Tempo Base:", tempo_base)

    return qtd_maquinas, qtd_jobs, recursos, velocidade, custo_tempo, tempo_base


def heuristica(qtd_maquinas, qtd_jobs, recursos, velocidade, custo_tempo, tempo_base):

    '''

    Aqui terá um programa que resolveria a heuristica

    '''


    #Valores aleatórios para a solução
    solucao1 = 123456
    solucao2 = 123.456
    solucao3 = [1, 2, 3, 4, 5, 6]


    return solucao1, solucao2, solucao3


#Função que salva uma solução em um arquivo CSV
def salva_solucao(arq_solucao, solucao1, solucao2, solucao3):
    #Cria uma arquivo para a solução
    with open(arq_solucao, 'w+') as f:

        #Variável tipo INTEIRA
        f.write("SOLUCAO1;{}\n".format(solucao1))

        #Variavel tipo FLOAT - com 2 números depois da vírgula
        f.write("SOLUCAO2;{0:4.2f}\n".format(solucao2))

        f.write("SOLUCAO;VALOR\n")
        for i, valor in enumerate(solucao3):
            f.write("{};{}\n".format(i, valor))


if __name__ == '__main__':
    pasta_instancias = "Instancias/"
    pasta_solucoes = "Solucoes/"

    #Percorrer todos os arquivos na pasta
    for arq_inst in os.listdir(pasta_instancias):
        extensao = arq_inst.split('.')[-1]

        #Verifica se a extensao é ".csv"
        if extensao == 'csv':
            # print("\n ============================================= \n")
            # print("INSTÂNCIA: ", arq_inst, "\n")

            #Le os dados da instância
            qtd_maquinas, qtd_jobs, recursos, velocidade, custo_tempo, tempo_base = le_dados(pasta_instancias + arq_inst)

            #Função responsável por resolver a heuristica
            solucao1, solucao2, solucao3 = heuristica(qtd_maquinas, qtd_jobs, recursos, velocidade, custo_tempo, tempo_base)

            #Salva a solução gerada no arquivo de solução
            salva_solucao(pasta_solucoes + arq_inst, solucao1, solucao2, solucao3)

